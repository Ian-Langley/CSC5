/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: valfo
 *
 * Created on February 5, 2020, 8:22 PM
 */

#include <cstdlib>
#include <iostream>
#include<iomanip>
#include<string>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv)
{
    string alphA;
    alphA = "What is up John";
    cout << alphA;
    return 0;
}

